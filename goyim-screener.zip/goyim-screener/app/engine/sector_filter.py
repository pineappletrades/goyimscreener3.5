"""One place for the sector filters used by the scan rule, the Screener page and the Strategy Test.

Two kinds, pick one:
  Rotation  - the stock's sector ETF vs SPY (Leading / Improving / Weakening / Lagging), as on the Rotation page.
  Valuation - the sector's valuation score, -10 (very expensive) to +10 (very cheap), as on the Rotation page's
              Valuation tab. Undervalued = +3 or more, Overvalued = -3 or less.
"""
import time
from datetime import date

MODES = {
    "off": ("Any sector", None),
    "leading": ("Leading sectors only", "rotation"),
    "leading_improving": ("Leading or Improving sectors", "rotation"),
    "not_lagging": ("Any sector but Lagging", "rotation"),
    "undervalued": ("Undervalued sectors only (score +3 or more)", "valuation"),
    "not_overvalued": ("Any sector but Overvalued (score above -3)", "valuation"),
}
ROTATION_OK = {"leading": ("Leading",), "leading_improving": ("Leading", "Improving"),
               "not_lagging": ("Leading", "Improving", "Weakening")}
UNDER, OVER = 3.0, -3.0
# labels used by the scan rule's dropdown (kept short) -> key
RULE_CHOICES = ["Leading only", "Leading or Improving", "Anything but Lagging", "Undervalued", "Not overvalued"]
_RULE_KEYS = dict(zip([c.lower() for c in RULE_CHOICES], ["leading", "leading_improving", "not_lagging",
                                                          "undervalued", "not_overvalued"]))
_VAL_CACHE = {}


def key(text):
    """'leading' / 'Leading only' / 'Undervalued' ... -> mode key ('off' if unknown)."""
    t = str(text or "off").strip().lower()
    if t in MODES:
        return t
    if t in _RULE_KEYS:
        return _RULE_KEYS[t]
    for k, (lab, _) in MODES.items():
        if t == lab.lower():
            return k
    return "off"


def label(k):
    return MODES[key(k)][0]


def kind(k):
    return MODES[key(k)][1]


def val_label(score):
    if score is None:
        return None
    return "Undervalued" if score >= UNDER else "Overvalued" if score <= OVER else "Fair value"


def passes(k, quadrant=None, score=None):
    k = key(k)
    if k == "off":
        return True
    if kind(k) == "rotation":
        return quadrant in ROTATION_OK[k]
    if score is None:
        return False
    return score >= UNDER if k == "undervalued" else score > OVER


# ---------------- live readings (scan, alerts, screener) ----------------
def valuation_scores(engine, max_age=3600):
    """{sector: {"score", "label"}} from the valuation snapshot, cached for an hour."""
    from . import valuation

    hit = _VAL_CACHE.get(id(engine))
    if hit and time.time() - hit[0] < max_age:
        return hit[1]
    snap = valuation.snapshot(engine, log=engine.log)
    out = {r["name"]: {"score": r["score"], "label": r["label"]} for r in snap["rows"] if r["kind"] == "sector"}
    _VAL_CACHE[id(engine)] = (time.time(), out)
    return out


def sector_of(engine, ticker, ctx=None):
    """Sector from the company-info cache, else SEC (and cache it)."""
    from datetime import datetime

    from . import store

    info = store.load("company_info.json", {}) or {}
    sec = (info.get(ticker) or {}).get("sic_sector")
    if sec or ticker in info:
        return sec
    if ctx is not None:
        return ctx.get("sic_sector")
    prov = engine.providers_with("company_info")
    if not prov:
        return None
    ci = prov[0].company_info(ticker)
    info[ticker] = dict(ci, fetched=datetime.now().isoformat(timespec="seconds"))
    store.save("company_info.json", info)
    return ci.get("sic_sector")


def live(engine, sector, want=("rotation", "valuation")):
    """{"sector", "etf", "quadrant", "score", "value"} for one sector today (missing parts left as None)."""
    from . import rotation

    out = {"sector": sector, "etf": rotation.SECTOR_ETF.get(sector), "quadrant": None, "score": None, "value": None}
    if out["etf"] is None:
        return out
    if "rotation" in want:
        try:
            st = rotation.sector_states(engine).get(sector) or {}
            out["quadrant"] = st.get("quadrant")
        except Exception as e:
            engine.log(f"Sector rotation: {e}")
    if "valuation" in want:
        try:
            v = valuation_scores(engine).get(sector) or {}
            out["score"], out["value"] = v.get("score"), val_label(v.get("score"))
        except Exception as e:
            engine.log(f"Sector valuation: {e}")
    return out


def tag(info):
    """'Technology (XLK) · Leading · valuation +4.2 Undervalued' for messages."""
    if not info or not info.get("sector"):
        return "Sector: unknown"
    bits = [f"Sector: {info['sector']}" + (f" ({info['etf']})" if info.get("etf") else "")]
    if info.get("quadrant"):
        bits.append(info["quadrant"])
    if info.get("score") is not None:
        bits.append(f"valuation {info['score']:+.1f} {info.get('value') or ''}".strip())
    return " · ".join(bits)


# ---------------- history (Strategy Test) ----------------
def _expanding_pct(values, min_n=120):
    """Percentile of each value vs all earlier values (only the past, so no look-ahead). NaN while warming up."""
    import numpy as np

    v = np.asarray(values, dtype="float64")
    out = np.full(len(v), np.nan)
    for i in range(min_n, len(v)):
        past = v[:i]
        past = past[~np.isnan(past)]
        if len(past) >= min_n and not np.isnan(v[i]):
            out[i] = 100.0 * np.mean(past < v[i])
    return out


def price_score_history(etf_close, spy_close):
    """Daily sector valuation score from its price parts only (the same two price checks the live score uses):
    relative to SPY (43%) and stretch above its 200-day average (57%), each as a percentile of its own
    history up to that day. -10 = most expensive, +10 = cheapest. Returns a pandas Series."""
    import numpy as np
    import pandas as pd

    j = pd.concat([etf_close.rename("a"), spy_close.rename("s")], axis=1, join="inner").dropna()
    rel = (j["a"] / j["s"]).values
    stretch = (j["a"] / j["a"].rolling(200).mean() - 1).values
    cheap_rel = 1 - 2 * _expanding_pct(rel, 250) / 100
    cheap_st = 1 - 2 * _expanding_pct(stretch, 120) / 100
    w_rel, w_st = 0.15, 0.20                      # SECTOR_WEIGHTS for rel / stretch
    num = np.where(np.isnan(cheap_rel), 0, w_rel * cheap_rel) + np.where(np.isnan(cheap_st), 0, w_st * cheap_st)
    den = np.where(np.isnan(cheap_rel), 0, w_rel) + np.where(np.isnan(cheap_st), 0, w_st)
    score = np.where(den >= 0.3, 10 * num / np.where(den == 0, 1, den), np.nan)
    return pd.Series(np.round(score, 1), index=j.index)
