"""Telegram commands: the app reads messages you send your bot and answers them.

Runs while the desktop app is open. Only your chat (the chat ID in Settings) gets answers;
anyone else who finds the bot is ignored. Read-only on your brokerage: no trading commands.
"""
import html
import threading
import time
from datetime import date, timedelta

import requests

from . import alerts as alerts_mod
from . import notify, store

E = html.escape
API = "https://api.telegram.org/bot{token}/{method}"

COMMANDS = [
    ("help", "Show the command list"),
    ("check", "Check a stock: /check NVDA"),
    ("price", "Price and % change: /price NVDA AAPL"),
    ("setups", "Latest scan results"),
    ("scan", "Run the scan now"),
    ("at", "Price alert: /at TSLA 300 (fires when it gets there, up or down)"),
    ("alert", "New alert: /alert NVDA ema 200 · /alert TSLA below 300"),
    ("alerts", "List your alerts"),
    ("delete", "Delete an alert: /delete 2"),
    ("watch", "Watchlist: /watch · /watch add AMD · /watch remove AMD"),
    ("earnings", "Upcoming earnings for your watchlist"),
    ("backtest", "Past 150/200 EMA pullbacks: /backtest NVDA · /backtest NVDA below (resistance)"),
    ("bestema", "Which EMA the stock respects most: /bestema NVDA"),
    ("gamma", "Gamma walls, flip, flow: /gamma SPY · /gamma SPY 580"),
    ("rotation", "Sector rotation vs SPY: /rotation · /rotation industries"),
    ("value", "Valuation scores −10…+10: sectors, gold, oil, bonds, breadth"),
    ("sector", "Sector overview (valuation + rotation) or one: /sector energy"),
    ("options", "Calls or shares? Best strike + expiration now: /options NVDA"),
    ("callstest", "Shares vs calls from your last Strategy Test (modeled)"),
    ("support", "Is anyone defending the EMA? /support NVDA · /support NVDA 200"),
    ("macro", "Macro regime: VIX, fear, trend, breadth, credit + where money is rotating"),
    ("theme", "Which trade a stock moves with and if money is leaving it: /theme WDC"),
    ("bids", "Today's bid/ask size samples: /bids NVDA · /bids (sampler status)"),
    ("toggles", "Every scan check and whether it's on: /toggles"),
    ("toggle", "Turn a scan check on/off: /toggle 3 on · /toggle macro off"),
    ("supportlog", "How the support signals have done on real alerts so far"),
    ("filter", "Scan sector filter: /filter leading · /filter undervalued · /filter off"),
    ("plan", "Gamma take profit / stop loss: /plan NVDA · /plan NVDA 180 · /plan results"),
    ("gammascan", "Gamma scan of the whole watchlist: /gammascan · /gammascan short"),
    ("valert", "Sector alert: /valert XLE above 6 · /valert gold below -5 · /valert XLK quadrant leading · /valert XLE turns"),
    ("valerts", "List / delete sector alerts: /valerts · /valert delete 2"),
    ("status", "Is the app running, market open, data sources"),
]

HELP = """<b>Goyim Screener commands</b>
/check NVDA — price, 150/200 EMA distance, and whether it passes each strategy
/price NVDA AAPL — price and % change (day, week, month)
/setups — the latest scan's setups
/scan — run the scan now and send the results
/at TSLA 300 — alert when TSLA reaches $300 (works up or down from today's price)
/alert NVDA ema 200 — when NVDA touches its 200 EMA
/alert NVDA sma 50 — same with an SMA
/alert NVDA near ema 150 2 — within 2% of the 150 EMA
/alert TSLA below 300 · /alert TSLA above 400 · /alert TSLA cross 350
  add <code>daily</code> to repeat once a day, or <code>and below 400</code> for an extra price check
/alerts — your alerts, numbered
/delete 2 — delete alert #2 (/off 2 and /on 2 pause and resume)
/watch — show the watchlist · /watch add AMD CRWD · /watch remove AMD
/backtest NVDA — every past 150/200 EMA pullback and how it did after
/backtest NVDA below — every rally INTO the 150/200 EMA from below: how often it acted as resistance (/backtest NVDA both for support + resistance)
/bestema NVDA — which EMA (5–250) it has bounced off most in 5 years
/gamma SPY — call/put walls, gamma flip, expected move, flow and whether the 150/200 EMA is backed
/gamma SPY 580 — will price reject at 580 or move through it fast?
/rotation — sectors leading/lagging SPY · also: /rotation style, industries, macro
/value — every sector, gold, silver, oil, bonds, dollar and breadth scored −10 (very expensive) to +10 (very cheap) vs its own history
/sector — every sector: valuation score + rotation quadrant · /sector energy for one in detail
/options NVDA — calls or shares for this setup: every liquid call on Public scored on your Strategy Test track record (win rate, avg win/loss, days held) — best strike, expiration, cost per contract, if right / if wrong, breakeven
/callstest — your last Strategy Test: shares vs modeled calls, and which expiration + strike did best
/support NVDA — every support check at the EMA it's sitting on: light-volume pullback, strong close, absorption, accumulation, line held before, gamma, option flow, bids · /support NVDA 200 for a specific EMA
/macro — macro regime −10…+10 (VIX level + spikes, SPY trend + drawdown, breadth, credit), fear level, and which themes money is leaving / moving into
/theme WDC — the ETF a stock really trades with (e.g. SMH) and whether that trade is weakening, seeing outflows or overvalued
/bids NVDA — today's bid/ask size samples for a stock · /bids for the sampler's status
/toggles — every scan check (support, macro, rotation, sector) and whether it's on · /toggle 3 on · /toggle macro off
/supportlog — on real alerts so far: how often the line held when each support signal was on vs off
/filter — the Investing scan's sector filter · /filter leading (Leading sectors only) · /filter improving (Leading or Improving) · /filter undervalued (score +3 or more) · /filter notover (anything but Overvalued) · /filter off
/plan NVDA — take profit and stop loss from the gamma map (call wall / pins above, put wall / flip below) · /plan NVDA 180 for an entry at $180
/plan results — how every gamma plan sent so far worked out (take profit or stop hit first)
/gammascan — gamma read for every watchlist ticker: positive/negative gamma, bullish/bearish lean, walls, expiration, big trades, possible hedges (/gammascan short = one line each)
/valert XLE above 6 · /valert gold below -5 · /valert XLK quadrant leading · /valert XLE turns — sector/asset alerts (checked after the close)
/valerts — list them · /valert delete 2
/earnings — upcoming earnings for your watchlist (next 14 days)
/status — app, market and data source status
Tip: send just a ticker in capitals (NVDA) or with $ ($nvda) to check it.

Commands work while the app is open on your PC."""


class TelegramBot:
    POLL_TIMEOUT = 25

    def __init__(self, api, log=print):
        self.api = api                  # desktop.Api: reuses its scan, alerts and engine
        self.log = log
        self.offset = None
        self.token = None
        self.last_error = None
        self._stop = False
        self._commands_set_for = None

    # ---------- plumbing ----------
    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="telegram-bot").start()

    def stop(self):
        self._stop = True

    def _creds(self):
        tg = store.secrets().get("telegram", {})
        return tg.get("bot_token"), str(tg.get("chat_id") or "").strip()

    def _call(self, token, method, http_timeout=30, **params):
        r = requests.post(API.format(token=token, method=method), json=params, timeout=http_timeout)
        data = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if not data.get("ok"):
            raise RuntimeError(f"Telegram {method}: {data.get('description') or r.status_code}")
        return data.get("result")

    def reply(self, text):
        token, chat = self._creds()
        notify.send(token, chat, text)

    def progress(self, text):
        """Best-effort 'working on it' note; the command still runs if it can't be sent."""
        try:
            self.reply(text)
        except Exception as e:
            self.log(f"Telegram progress note not sent: {e}")

    def _loop(self):
        while not self._stop:
            enabled = store.settings().get("telegram_commands", True)
            token, chat = self._creds()
            if not (enabled and token and chat):
                time.sleep(10)
                continue
            if token != self.token:                 # new or changed bot: start fresh
                self.token, self.offset = token, None
            try:
                if self._commands_set_for != token:
                    self._call(token, "setMyCommands", commands=[{"command": c, "description": d} for c, d in COMMANDS])
                    self._commands_set_for = token
                params = {"timeout": self.POLL_TIMEOUT, "allowed_updates": ["message"]}
                if self.offset is not None:
                    params["offset"] = self.offset
                updates = self._call(token, "getUpdates", http_timeout=self.POLL_TIMEOUT + 10, **params) or []
                self.last_error = None
                for u in updates:
                    self.offset = u["update_id"] + 1
                    msg = u.get("message") or {}
                    if str((msg.get("chat") or {}).get("id")) != chat:
                        continue                    # not you: ignore
                    if time.time() - msg.get("date", 0) > 600:
                        continue                    # sent while the app was closed long ago
                    text = (msg.get("text") or "").strip()
                    if text:
                        threading.Thread(target=self._handle, args=(text,), daemon=True).start()
            except Exception as e:
                err = str(e)
                if err != self.last_error:
                    self.log(f"Telegram commands: {err}")
                self.last_error = err
                # 409 = a webhook is set or another copy of the app is reading this bot
                time.sleep(30 if "409" in err or "Conflict" in err or "webhook" in err.lower() else 8)

    def _handle(self, text):
        try:
            out = self.handle(text)
        except Exception as e:
            out = f"⚠️ {E(str(e))}"
        if out:
            try:
                self.reply(out)
            except Exception as e:
                self.log(f"Telegram reply failed: {e}")

    # ---------- commands ----------
    def handle(self, text):
        parts = text.split()
        cmd = parts[0].lower().lstrip("/").split("@")[0]
        args = parts[1:]
        fn = {
            "start": self.c_help, "help": self.c_help, "check": self.c_check, "price": self.c_price,
            "p": self.c_price, "setups": self.c_setups, "scan": self.c_scan, "alert": self.c_alert, "at": self.c_at, "pricealert": self.c_at,
            "alerts": self.c_alerts, "delete": self.c_delete, "del": self.c_delete, "off": self.c_off,
            "on": self.c_on, "watch": self.c_watch, "watchlist": self.c_watch, "earnings": self.c_earnings,
            "status": self.c_status, "backtest": self.c_backtest, "bt": self.c_backtest,
            "bestema": self.c_bestema, "ema": self.c_bestema, "gamma": self.c_gamma, "gex": self.c_gamma,
            "rotation": self.c_rotation, "sectors": self.c_rotation,
            "value": self.c_value, "valuation": self.c_value,
            "options": self.c_options, "calls": self.c_options, "callstest": self.c_callstest, "support": self.c_support, "sup": self.c_support, "macro": self.c_macro, "vix": self.c_macro,
            "theme": self.c_theme, "bids": self.c_bids, "book": self.c_bids, "toggles": self.c_toggles,
            "toggle": self.c_toggle, "supportlog": self.c_supportlog,
            "plan": self.c_plan, "tp": self.c_plan, "filter": self.c_filter, "sectorfilter": self.c_filter, "sector": self.c_sector, "gammascan": self.c_gammascan, "gscan": self.c_gammascan,
            "valert": self.c_valert, "valerts": self.c_valerts,
        }.get(cmd)
        if fn is None:
            word = parts[0].lstrip("$")
            if (not text.startswith("/") and len(parts) == 1 and word.isalpha() and len(word) <= 5
                    and (parts[0].startswith("$") or word.isupper())):
                return self.c_check([word])         # "NVDA" or "$nvda" on its own = /check
            return "I don't know that one. Send /help for the list."
        return fn(args)

    def c_help(self, args):
        return HELP

    def _tickers(self, args):
        return [a.strip(",").upper() for a in args if a.strip(",")]

    def c_price(self, args):
        tickers = self._tickers(args)[:10]
        if not tickers:
            return "Which ticker? e.g. /price NVDA"
        rows = alerts_mod.bar_rows(self.api._engine, tickers)
        lines = []
        for r in rows:
            if r.get("price") is None:
                lines.append(f"<b>{E(r['ticker'])}</b> no price (check the ticker or Public.com key)")
                continue
            pc = lambda v: "–" if v is None else f"{v:+.1f}%"
            lines.append(f"<b>{E(r['ticker'])}</b> ${r['price']:,.2f}  day {pc(r['day'])} · wk {pc(r['week'])} · mo {pc(r['month'])} · 3mo {pc(r['m3'])}")
        return "\n".join(lines)

    def _ma_lines(self, t):
        from .scanner import Context
        e = self.api._engine
        try:
            bars = Context(e, t, {"id": "bot", "fast": 150, "slow": 200}, e.shared_cache(t)).get("bars")
        except Exception as ex:
            return None, f"No price data for {E(t)}: {E(str(ex))}"
        if bars is None or not len(bars):
            return None, f"No price data for {E(t)}"
        try:
            q, _ = e.call_first("quotes", [t])
            price = (q.get(t) or {}).get("last") or float(bars["close"].iloc[-1])
        except Exception:
            price = float(bars["close"].iloc[-1])
        closes = alerts_mod.completed_closes(bars)
        out = []
        for n in (150, 200):
            ma = alerts_mod.live_ma(closes, price, n, "EMA")
            if ma:
                d = (price / ma - 1) * 100
                where = "above" if d >= 0 else "below"
                out.append(f"EMA {n}: ${ma:,.2f} ({abs(d):.1f}% {where})")
        return price, "\n".join(out)

    def c_check(self, args):
        tickers = self._tickers(args)
        if not tickers:
            return "Which ticker? e.g. /check NVDA"
        t = tickers[0]
        price, ma_text = self._ma_lines(t)
        if price is None:
            return ma_text
        lines = [f"<b>{E(t)}</b> ${price:,.2f}", ma_text]
        res = self.api.check_ticker(t)
        if not res.get("ok"):
            lines.append(f"Strategies: {E(res.get('error', 'not checked'))}")
            return "\n".join(lines)
        icon = {"setup": "✅", "approaching": "🟡", "fail": "❌", "unavailable": "⚪"}
        for r in res["scan"].get("results", []):
            if r["ticker"] != t:
                continue
            failed = [x["name"] for x in r.get("rules", []) if x.get("result") == "fail"]
            near = [x["name"] for x in r.get("rules", []) if x.get("result") == "near"]
            s = f"{icon.get(r['status'], '•')} <b>{E(r.get('profile_name', r['profile']))}</b>: {r['status']}"
            if r.get("grade"):
                s += f" (grade {r['grade']})"
            if failed:
                s += "\n   missing: " + E(", ".join(failed[:4]))
            elif near:
                s += "\n   close on: " + E(", ".join(near[:4]))
            lines.append(s)
        return "\n".join(lines)

    def c_setups(self, args):
        last = store.load("last_scan.json", None)
        if not last:
            return "No scan yet. Send /scan to run one."
        return notify.build_message(last)

    def c_scan(self, args):
        if self.api._engine.status.get("running"):
            return "A scan is already running. I'll send the results when it's done."
        self.progress("🔎 Scanning… this can take a while for the all-stocks strategies.")
        res = self.api._run_scan(False)
        if not res.get("ok"):
            return f"⚠️ Scan failed: {E(res.get('error', ''))}"
        return notify.build_message(res["scan"])

    # ----- alerts -----
    def _alert_list(self):
        return self.api._alerts.alerts()

    def c_alerts(self, args):
        lst = self._alert_list()
        if not lst:
            return "No alerts. e.g. /alert NVDA ema 200"
        lines = ["<b>Your alerts</b>"]
        for i, a in enumerate(lst, 1):
            state = "" if a.get("enabled", True) else " (off)"
            lines.append(f"{i}. <b>{E(a['ticker'])}</b> {E(alerts_mod.describe(a))}{state}")
        lines.append("\n/delete N to remove · /off N to pause · /on N to resume")
        return "\n".join(lines)

    def _pick(self, args):
        lst = self._alert_list()
        if not args or not args[0].isdigit() or not (1 <= int(args[0]) <= len(lst)):
            raise ValueError(f"Send the alert number from /alerts (1 to {len(lst)})" if lst else "You have no alerts")
        return lst[int(args[0]) - 1]

    def c_delete(self, args):
        a = self._pick(args)
        self.api._alerts.delete_alert(a["id"])
        return f"🗑 Deleted: {E(a['ticker'])} {E(alerts_mod.describe(a))}"

    def c_off(self, args):
        a = self._pick(args)
        self.api._alerts.save_alert({**a, "enabled": False})
        return f"⏸ Paused: {E(a['ticker'])} {E(alerts_mod.describe(a))}"

    def c_on(self, args):
        a = self._pick(args)
        self.api._alerts.save_alert({**a, "enabled": True, "state": {}})
        return f"▶️ On: {E(a['ticker'])} {E(alerts_mod.describe(a))}"

    @staticmethod
    def parse_alert(args):
        """/alert NVDA ema 200 [above|below|either] [daily] [and below 400]
           /alert NVDA near ema 150 2
           /alert TSLA below 300 | above 400 | cross 350"""
        if len(args) < 2:
            raise ValueError("e.g. /alert TSLA 300 · /alert NVDA ema 200 · /alert NVDA near ema 150 2 · /alert TSLA below 300")
        words = [w.lower().strip(",$") for w in args[1:]]
        a = {"ticker": args[0].upper().strip(","), "repeat": "once", "note": "Set from Telegram"}
        if "daily" in words:
            a["repeat"] = "daily"
            words.remove("daily")
        if "and" in words:                      # extra price condition
            i = words.index("and")
            tail = words[i + 1:]
            words = words[:i]
            if len(tail) >= 2 and tail[0] in ("above", "below"):
                a["and_cond"], a["and_price"] = tail[0], float(tail[1])
        if words[0].replace(".", "", 1).isdigit():
            a["kind"] = "price_auto"               # just a price: direction worked out from today's price
            a["price"] = float(words[0])
            return a
        if words[0] == "near":
            words = words[1:]
            a["kind"] = "ma_near"
            a["near_pct"] = float(words[2]) if len(words) > 2 else 1.0
        if words[0] in ("ema", "sma"):
            a.setdefault("kind", "ma_touch")
            a["ma_type"] = words[0].upper()
            a["length"] = int(words[1])
            if a["kind"] == "ma_touch":
                a["direction"] = next((w for w in words[2:] if w in ("above", "below", "either")), "either")
        elif words[0] in ("above", "below", "cross", "crosses"):
            a["kind"] = {"above": "price_above", "below": "price_below"}.get(words[0], "price_cross")
            a["price"] = float(words[1])
        else:
            raise ValueError("After the ticker use ema / sma / near / above / below / cross")
        return a

    def c_at(self, args):
        """/at TSLA 300 — alert when TSLA reaches $300 (up or down from here)."""
        if len(args) < 2:
            return "e.g. /at TSLA 300 — alerts when TSLA reaches $300, whichever way it has to go"
        return self.c_alert(args[:2] + args[2:])

    def c_alert(self, args):
        a = self.parse_alert(args)
        if a.get("kind") == "price_auto":
            try:
                q, _ = self.api._engine.call_first("quotes", [a["ticker"]])
                last = (q.get(a["ticker"]) or {}).get("last")
            except Exception:
                last = None
            if not last:
                a["kind"] = "price_cross"               # unknown price now: fire when it crosses the level
            else:
                a["kind"] = "price_above" if a["price"] > last else "price_below"
                a["note"] = f"Set at ${last:,.2f} from Telegram"
        saved = self.api._alerts.save_alert(a)
        return (f"🔔 Alert set: <b>{E(saved['ticker'])}</b> {E(alerts_mod.describe(saved))}"
                f" ({'once a day' if saved.get('repeat') == 'daily' else 'once'})\n"
                "Checked every minute during market hours while the app is open.")

    # ----- watchlist / earnings / status -----
    def c_watch(self, args):
        wl = store.watchlist()
        if not args:
            return f"<b>Watchlist ({len(wl)})</b>\n" + (E(", ".join(wl)) or "empty") + \
                "\n/watch add AMD · /watch remove AMD"
        action, tickers = args[0].lower(), self._tickers(args[1:])
        if action in ("add", "+") and tickers:
            new = wl + [t for t in tickers if t not in wl]
        elif action in ("remove", "rm", "del", "-") and tickers:
            new = [t for t in wl if t not in tickers]
        else:
            return "e.g. /watch add AMD CRWD or /watch remove AMD"
        saved = store.save_watchlist(new)
        return f"Watchlist ({len(saved)}): {E(', '.join(saved))}"

    def c_earnings(self, args):
        e = self.api._engine
        if not e.providers_with("earnings_calendar"):
            return "Earnings dates need Finnhub or Alpha Vantage (add a key on the Data sources page)."
        watch = set(store.watchlist()) | set(store.load("bar_watchlist.json", []))
        today = date.today()
        events, src = e.call_first("earnings_calendar", today.isoformat(), (today + timedelta(days=14)).isoformat())
        mine = sorted((ev for ev in events if ev["symbol"] in watch), key=lambda ev: ev["date"])
        if not mine:
            return "None of your watchlist reports in the next 14 days."
        lines = ["<b>Upcoming earnings (next 14 days)</b>"]
        for ev in mine:
            d = date.fromisoformat(ev["date"]).strftime("%a %b %d")
            extra = f" · {ev['time']}" if ev.get("time") else ""
            est = f" · EPS est ${ev['eps_est']:.2f}" if ev.get("eps_est") is not None else ""
            lines.append(f"{d}: <b>{E(ev['symbol'])}</b>{E(extra)}{est}")
        return "\n".join(lines)

    def c_backtest(self, args):
        words = {a.lower() for a in args}
        side = "below" if words & {"below", "resistance", "res", "up"} else "both" if "both" in words else "above"
        tickers = self._tickers([a for a in args if a.lower() not in ("below", "resistance", "res", "up", "both", "above", "support")])
        if not tickers:
            return "Which ticker? e.g. /backtest NVDA · /backtest NVDA below (rallies into the EMA from below = resistance test)"
        r = self.api.run_backtest(tickers[0], {"side": side} if side != "above" else None)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'Backtest failed'))}"
        p, evs = r["params"], r["events"]
        if not evs:
            return f"<b>{E(r['ticker'])}</b>: no {'tests from below' if side != 'above' else 'pullbacks'} of the {p['kind']} {p['fast']}/{p['slow']} since {r['period']['start']}."
        if side != "above":
            pc = lambda v: "–" if v is None else f"{v:+.1f}%"
            lines = [f"<b>{E(r['ticker'])} resistance check</b> · {p['kind']} {p['fast']}/{p['slow']} since {r['period']['start']}"]
            keys = [("fast", p["fast"]), ("slow", p["slow"])] if side == "below" else \
                [("fast_support", f"{p['fast']} support"), ("slow_support", f"{p['slow']} support"),
                 ("fast_resistance", f"{p['fast']} resistance"), ("slow_resistance", f"{p['slow']} resistance")]
            for k, name in keys:
                x = r["summary"].get(k)
                if x and x.get("held_rate") is not None:
                    verb = "held" if k.endswith("support") else "turned price back"
                    lines.append(f"{p['kind']} {name}: {verb} {round(x['held_rate'] * x['held_n'] / 100)} of {x['held_n']} times "
                                 f"(<b>{x['held_rate']:.0f}%</b>) · avg 1mo after {pc(x['horizons']['20']['avg'])}")
            lines.append(f"Held = no close more than {p['held_pct']}% through the line within {p['held_days']} days.")
            lines.append("\n<b>Last 5 tests</b>")
            for e in evs[-5:][::-1]:
                res = "rejected" if e.get("held") and e["side"] == "below" else "held" if e.get("held") else \
                    "broke through" if e.get("held") is False else "too recent"
                lines.append(f"{e['date']} · {p['fast'] if e['line'] == 'fast' else p['slow']} from {e['side']} · ${e['price']:,.2f} → {res}, 1mo {pc(e['returns']['20'])}")
            return "\n".join(lines)
        sm = r["summary"]["all"]
        pc = lambda v: "–" if v is None else f"{v:+.1f}%"
        lines = [f"<b>{E(r['ticker'])} backtest</b> · {p['kind']} {p['fast']}/{p['slow']} pullbacks since {r['period']['start']}",
                 f"{len(evs)} pullbacks ({(r['summary'].get('fast') or {}).get('count', 0)} to the {p['fast']}, "
                 f"{(r['summary'].get('slow') or {}).get('count', 0)} to the {p['slow']})"]
        for h, label in (("20", "1 month"), ("60", "3 months"), ("252", "1 year")):
            x, b = sm["horizons"][h], r["baseline"][h]
            if x["n"]:
                lines.append(f"After {label}: {x['win']:.0f}% up, avg {pc(x['avg'])} (any day: avg {pc(b['avg'])})")
        lines.append(f"Avg deepest drop in the next 60 days: {pc(sm['avg_max_drop_60'])}")
        lines.append("\n<b>Last 5</b>")
        for e in evs[-5:][::-1]:
            lines.append(f"{e['date']} · {p['fast'] if e['line'] == 'fast' else p['slow']} · ${e['price']:,.2f} → "
                         f"1mo {pc(e['returns']['20'])}, 3mo {pc(e['returns']['60'])}")
        return "\n".join(lines)

    def c_bestema(self, args):
        tickers = self._tickers(args)
        if not tickers:
            return "Which ticker? e.g. /bestema NVDA"
        r = self.api.find_emas(tickers[0])
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'Failed'))}"
        if not r.get("best"):
            return f"<b>{E(r['ticker'])}</b>: no line was tested enough times since {r['period']['start']}."
        k = r["params"]["kind"]
        pc = lambda v: "–" if v is None else f"{v:+.1f}%"
        lines = [f"<b>{E(r['ticker'])}: most respected {k}</b> (since {r['period']['start']})"]
        for i, x in enumerate(r["top"][:5], 1):
            lines.append(f"{i}. {k} {x['length']}: bounced {x['bounces']}/{x['tests']} ({x['respect']:.0f}%), "
                         f"typical distance {x['avg_abs_dist']:.1f}%, now {pc(x['now_dist'])}")
        b = r["top"][0]
        lines.append(f"\nPrice is {pc(b['now_dist'])} from the {k} {b['length']} (${b['now_ma']:,.2f}). "
                     f"/alert {E(r['ticker'])} {k.lower()} {b['length']} above")
        return "\n".join(lines)

    def c_callstest(self, args):
        r = (self.api.get_strategy_bt() or {}).get("result")
        if not r or not r.get("options"):
            return "No Strategy Test with calls yet. Run one in the app's Strategy Test page."
        o, pf, s_ = r["options"], r["portfolio"], r["stats"]
        pc = lambda v: "–" if v is None else f"{v:+.1f}%"
        st = o["settings"]
        lines = [f"<b>Shares vs calls</b> · {r['alerts_total']} alerts, {r['info']['first_day']} → {r['info']['last_day']} (calls modeled with Black-Scholes)",
                 f"Shares: {pc(pf.get('cagr'))}/yr · worst drop {pc(pf.get('maxdd'))} · avg trade {pc(s_.get('avg'))}",
                 f"Calls ({st['dte']} trading days, delta {st['delta']:.2f}): {pc(o['portfolio'].get('cagr'))}/yr · worst drop {pc(o['portfolio'].get('maxdd'))} · avg trade {pc(o['stats'].get('avg'))}",
                 f"Best growth: {E(o['winner'].get('cagr') or '–')} · best return ÷ drop: {E(o['winner'].get('risk') or '–')}",
                 "\n<b>Top 5 by yearly growth</b>"]
        for x in sorted(o["grid"], key=lambda x: -(x["portfolio"].get("cagr") or -1e9))[:5]:
            lines.append(f"{E(x['label'])}: {pc(x['portfolio'].get('cagr'))}/yr · drop {pc(x['portfolio'].get('maxdd'))} · win {x['stats'].get('win') or 0:.0f}%")
        return "\n".join(lines)

    def c_options(self, args):
        from .options import finder_line
        tickers = self._tickers(args[:1])
        if not tickers:
            return "Which ticker? e.g. /options NVDA"
        self.progress(f"Checking {tickers[0]} option chain…")
        r = self.api.options_finder(tickers[0])
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        sc = r["scenario"]
        lines = [f"<b>{E(r['ticker'])} calls or shares</b> · price ${r['spot']:,.2f}",
                 finder_line(r),
                 f"Based on {E(sc['source'])}: wins {sc['p_win'] * 100:.0f}% of the time, avg win {sc['up_pct']:+.1f}%, avg loss {sc['down_pct']:+.1f}%, ~{sc['days']} trading days"]
        if r["candidates"]:
            lines.append("\n<b>Best calls</b> (expected · if right · if wrong · cost)")
            for c in r["candidates"][:5]:
                lines.append(f"{c['expiration']} ${c['strike']:g}C Δ{c['delta']:.2f} · {c['ev']:+.0f}% · {c['if_right']:+.0f}% · {c['if_wrong']:+.0f}% · "
                             f"${c['cost']:,.0f} · spread {c['spread_pct']:.0f}% · OI {c['oi']}")
        if r.get("steady") and r["steady"] is not r.get("best"):
            st_ = r["steady"]
            lines.append(f"Steadier (deep in the money): {st_['expiration']} ${st_['strike']:g}C Δ{st_['delta']:.2f} · expected {st_['ev']:+.0f}%, if wrong {st_['if_wrong']:+.0f}%")
        lines.append("Shares: expected {:+.0f}% · if right {:+.0f}% · if wrong {:+.0f}%".format(r["shares"]["ev"], r["shares"]["if_right"], r["shares"]["if_wrong"]))
        return "\n".join(lines)

    def c_support(self, args):
        from .support import ALL
        nums = [a for a in args if a.isdigit()]
        tickers = self._tickers([a for a in args if not a.isdigit()])
        if not tickers:
            return "Which ticker? e.g. /support NVDA or /support NVDA 200"
        r = self.api.support_check(tickers[0], int(nums[0]) if nums else None)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        lines = [f"<b>{E(r['ticker'])} support check at the {E(r['line'])}</b> (${r['level']:,.2f}, price {r['dist_pct']:+.1f}% from it)",
                 f"<b>{r['score']}</b> checks passed"]
        for k, lab, _ in ALL:
            x = r["signals"].get(k)
            if x is None:
                continue
            mark = "✅" if x["ok"] else "❌" if x["ok"] is False else "➖"
            lines.append(f"{mark} {lab}: {E(x['detail'])}")
        return "\n".join(lines)

    def c_macro(self, args):
        from .macro import lines as macro_lines
        r = self.api.get_macro()
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        out = macro_lines(r)
        names = {"vix_level": "VIX level", "vix_spike": "VIX vs 20-day avg", "trend": "SPY trend", "drawdown": "SPY drawdown",
                 "breadth": "Breadth (RSP vs SPY)", "credit": "Credit (HYG vs IEF)"}
        out.append("\n<b>Parts</b> (−1 risk-off … +1 risk-on)")
        for k, v in r["components"].items():
            out.append(f"{names.get(k, k)}: {'n/a' if v is None else f'{v:+.1f}'}")
        risky = [f"{e_} ({t['name']}): {', '.join(t['flags'])}" for e_, t in r["themes"].items() if t["risk"] >= 2]
        if risky:
            out.append("\n<b>Themes at rotation risk</b>\n" + "\n".join(E(x) for x in risky[:8]))
        return "\n".join(out)

    def c_theme(self, args):
        tickers = self._tickers(args[:1])
        if not tickers:
            return "Which ticker? e.g. /theme WDC"
        r = self.api.get_theme(tickers[0])
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        t = r["theme"] or {}
        lines = [f"<b>{E(r['ticker'])}</b> trades most with <b>{E(r['etf'])}</b> ({E(t.get('name', ''))}), correlation {r['corr']}",
                 E(t.get("text", ""))]
        if t.get("flags"):
            lines.append(("⚠️ Rotation risk: " if t["risk"] >= 2 else "Warning: ") + ", ".join(t["flags"]))
        else:
            lines.append("✅ No rotation warnings for this trade")
        if r.get("into"):
            lines.append("💰 Money moving into: " + ", ".join(r["into"]))
        if r.get("out_of"):
            lines.append("💸 Money leaving: " + ", ".join(r["out_of"]))
        return "\n".join(lines)

    def c_bids(self, args):
        tickers = self._tickers(args[:1]) if args else []
        r = self.api.book_status(tickers[0] if tickers else None)
        head = (f"Bid/ask sampler: {'on' if r['enabled'] else 'OFF'} · market {'open' if r['market_open'] else 'closed'} · "
                f"watching {r['watching']} stocks · last sample {r['last_run'] or 'none yet'}")
        if not tickers:
            return head
        m = r.get("metrics") or {}
        if not m.get("samples"):
            return head + f"\n{E(r['ticker'])}: no samples today (it's sampled while the market is open and it's near an EMA, on your watchlist, or has an EMA alert)."
        growth = "n/a" if m["bid_growth"] is None else f"{m['bid_growth']:+.0f}%"
        lines = [head, f"<b>{E(r['ticker'])}</b> today: {m['samples']} samples {m['first']}–{m['last']}",
                 f"Bids {m['bid_share'] * 100:.0f}% of top-of-book size · bid size {growth} through the day"]
        for x in r["samples"][-8:]:
            px = lambda v: "–" if v is None else f"${v:,.2f}"
            lines.append(f"{x['t']} {px(x.get('p'))} · bid {x.get('bs')} @ {px(x.get('b'))} · ask {x.get('as')} @ {px(x.get('a'))}")
        return "\n".join(lines)

    def c_toggles(self, args):
        r = self.api.list_toggles()
        lines = [f"<b>{E(r['profile'])}</b> scan checks (/toggle N on|off)"]
        group = None
        for i, x in enumerate(r["toggles"], 1):
            if x["group"] != group:
                group = x["group"]
                lines.append(f"\n<b>{E(group)}</b>")
            lines.append(f"{i}. {'✅' if x['enabled'] else '⬜'} {E(x['name'])}")
        return "\n".join(lines)

    def c_toggle(self, args):
        if len(args) < 2 or args[-1].lower() not in ("on", "off"):
            return "Use: /toggle 3 on · /toggle macro off (send /toggles for the numbers)"
        on = args[-1].lower() == "on"
        key = " ".join(args[:-1]).lower()
        lst = self.api.list_toggles()["toggles"]
        hit = None
        if key.isdigit() and 1 <= int(key) <= len(lst):
            hit = lst[int(key) - 1]
        else:
            alias = {"macro": "macro_regime", "theme": "theme_health", "rotation": "theme_health", "repeat": "no_repeat_failure",
                     "sector": "leading_sector", "bids": "sup_bids", "gamma": "sup_gamma", "flow": "sup_flow",
                     "volume": "sup_light_pullback", "close": "sup_strong_close", "absorption": "sup_absorption",
                     "accumulation": "sup_accumulation", "held": "sup_respected", "history": "sup_respected"}.get(key, key)
            hit = next((x for x in lst if x["id"] == alias), None) or next((x for x in lst if key in x["name"].lower()), None)
        if hit is None:
            return f"No check matching '{E(key)}'. Send /toggles for the list."
        r = self.api.set_toggle(hit["id"], on)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        return f"{'✅' if on else '⬜'} <b>{E(r['name'])}</b> is now {'ON' if on else 'off'} for {E(r['profile'])}. Applies from the next scan."

    def c_supportlog(self, args):
        r = self.api.support_journal_results()
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        s = r["summary"]
        if not s["checks"]:
            return "No support checks saved yet. Each scan setup's checks are saved and graded 10 trading days later."
        lines = [f"<b>Support checks on real alerts</b>: {s['checks']} saved · {s['finished']} graded"
                 + (f" · line held {s['held_rate']:.0f}% overall" if s.get("held_rate") is not None else "")]
        for x in r["signals"]:
            w, wo = x["with"], x["without"]
            if not w["held_n"] and not wo["held_n"]:
                continue
            f = lambda d: "–" if d["held_rate"] is None else f"{d['held_rate']:.0f}% ({d['held_n']})"
            lines.append(f"{E(x['label'])}: held {f(w)} when on vs {f(wo)} when off")
        return "\n".join(lines)

    def c_filter(self, args):
        if not args:
            r = self.api.get_sector_filter()
            return (f"<b>{E(r['profile'])}</b> sector filter: <b>{E(r['label'])}</b>\n"
                    "Change it: /filter leading · /filter improving · /filter undervalued · /filter notover · /filter off")
        word = args[0].lower()
        mode = {"leading": "leading", "lead": "leading", "improving": "leading_improving", "notlagging": "not_lagging",
                "undervalued": "undervalued", "under": "undervalued", "cheap": "undervalued", "value": "undervalued",
                "notover": "not_overvalued", "notovervalued": "not_overvalued", "off": "off", "none": "off", "all": "off"}.get(word)
        if mode is None:
            return "Use: /filter leading · /filter improving · /filter undervalued · /filter notover · /filter off"
        r = self.api.set_sector_filter(mode)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'failed'))}"
        return f"✅ <b>{E(r['profile'])}</b> now alerts: <b>{E(r['label'])}</b>. Applies from the next scan."

    def c_plan(self, args):
        if args and args[0].lower() in ("results", "result", "track", "stats"):
            r = self.api.gamma_plan_results()
            if not r.get("ok"):
                return f"⚠️ {E(r.get('error', 'failed'))}"
            s = r["summary"]
            if not s.get("plans"):
                return "No gamma plans yet. They're saved each time a scan setup or EMA alert is sent."
            lines = [f"<b>Gamma plans so far</b>: {s['plans']} · closed {s['closed']} · open {s['open']}"]
            if s.get("closed"):
                lines.append(f"Take profit hit first: <b>{s['target_pct']:.0f}%</b> · avg result {s['avg_ret']:+.1f}% · avg {s['avg_days']:.0f} days")
            for x in r["rows"][:10]:
                res = {"target": "🎯 TP", "stop": "🛑 SL", "open": "⏳ open"}.get(x["result"], x["result"])
                lines.append(f"{E(x['ticker'])} {x['date']} ${x['entry']:,.2f} → {res} {x.get('ret', 0):+.1f}%")
            return "\n".join(lines)
        tickers = self._tickers(args[:1])
        if not tickers:
            return "Which ticker? e.g. /plan NVDA or /plan NVDA 180"
        entry = None
        if len(args) > 1:
            try:
                entry = float(args[1].replace("$", "").replace(",", ""))
            except ValueError:
                pass
        from .gamma import plan_line
        r = self.api.gamma_plan(tickers[0], entry)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error') or 'No plan')}"
        pl = r["plan"]
        line = plan_line(pl)
        if not line:
            return f"{E(tickers[0])}: no clear gamma levels within range of ${pl['entry']:,.2f}"
        return f"<b>{E(tickers[0])}</b> entry ${pl['entry']:,.2f} · gamma {pl.get('regime') or '–'}\n{E(line)}"

    def c_gamma(self, args):
        tickers = self._tickers(args[:1])
        if not tickers:
            return "Which ticker? e.g. /gamma SPY or /gamma SPY 580"
        t = tickers[0]
        g = self.api.get_gamma(t, "near")
        if not g.get("ok"):
            return f"⚠️ {E(g.get('error', 'Gamma failed'))}"
        money = lambda v: "–" if v is None else (("-" if v < 0 else "+") + (f"${abs(v)/1e9:.2f}B" if abs(v) >= 1e9 else f"${abs(v)/1e6:.0f}M"))
        p = lambda v: "–" if v is None else f"${v:,.2f}"
        lines = [f"<b>{E(t)} gamma</b> · price {p(g['spot'])} · next {len(g['used'])} expirations",
                 f"Dealer gamma: <b>{g['regime']}</b> ({money(g['total_gex'])} per 1%) — "
                 + ("moves damped, levels hold better" if g["regime"] == "positive" else "moves can speed up"),
                 f"Gamma flip: {p(g['flip'])}" + (f" (price {'above' if g['spot'] >= g['flip'] else 'below'})" if g.get("flip") else ""),
                 f"Call wall (ceiling/target): {p(g['call_wall_above'])} · Put wall (support): {p(g['put_wall_below'])}"]
        em = g.get("expected_move")
        if em:
            lines.append(f"Expected move to {em['date']}: ±{em['pct']:.1f}% ({p(em['low'])} – {p(em['high'])})")
        if g.get("pins"):
            lines.append("Pin/reject: " + ", ".join(f"${x:,.0f}" for x in g["pins"][:4]))
        if g.get("pockets"):
            lines.append("Air pockets (fast): " + ", ".join(f"${a:,.0f}–${b:,.0f}" for a, b in g["pockets"][:2]))
        for c in g["confirmations"]:
            if c["name"] in ("EMA 150", "EMA 200", "EMA 50"):
                lines.append(f"{c['name']} {p(c['level'])}: {c['label']}")
        f = g["flow"]
        lines.append(f"Flow today (est.): net premium {money(f['net_premium'])} · {f['tilt']}")
        if len(args) > 1:
            try:
                v = self.api.gamma_check(t, float(args[1].strip("$,")))
                if v.get("ok"):
                    word = {"reject": "likely to stall/reject", "slow": "likely to slow down",
                            "fast": "could move through fast", "open": "little in the way"}[v["verdict"]]
                    lines.append(f"\n<b>At {p(v['price'])}: {word}</b>\n{E(v['note'])}")
            except ValueError:
                pass
        return "\n".join(lines)

    def c_rotation(self, args):
        word = (args[0].lower() if args else "sectors")
        group = {"sectors": "Sectors", "sector": "Sectors", "style": "Size & style", "size": "Size & style",
                 "industries": "Industries", "industry": "Industries", "macro": "Macro", "mine": "My list",
                 "my": "My list"}.get(word, "Sectors")
        r = self.api.get_rotation(group)
        if not r.get("ok"):
            return f"⚠️ {E(r.get('error', 'Rotation failed'))}"
        sm, rows = r["summary"], {x["ticker"]: x for x in r["rows"]}
        pc = lambda v: "–" if v is None else f"{v:+.1f}%"
        lines = [f"<b>Rotation · {E(group)}</b> (vs SPY)"]
        for q, icon in (("Leading", "🟢"), ("Improving", "🔵"), ("Weakening", "🟡"), ("Lagging", "🔴")):
            if sm.get(q):
                lines.append(f"{icon} {q}: " + ", ".join(f"{t} {pc(rows[t]['rel']['1M'])}" for t in sm[q]))
        lines.append("In (1W): " + ", ".join(sm["inflow"]) + " · Out: " + ", ".join(sm["outflow"]))
        if sm.get("turning_up"):
            lines.append("Turning up: " + ", ".join(sm["turning_up"]))
        if sm.get("rolling_over"):
            lines.append("Rolling over: " + ", ".join(sm["rolling_over"]))
        lines.append("<i>% = 1-month performance vs SPY</i>")
        return "\n".join(lines)

    def c_value(self, args):
        v = self.api.get_valuation()
        if not v.get("ok"):
            return f"⚠️ {E(v.get('error', 'Valuation failed'))}"
        rows = [r for r in v["rows"] if r["score"] is not None]
        lines = ["📊 <b>Valuation vs own history</b>  (+10 very cheap · −10 very expensive)"]
        for kind, title in (("market", None), ("sector", "Sectors"), ("asset", "Gold, oil, bonds, dollar"), ("breadth", None)):
            grp = sorted([r for r in rows if r["kind"] == kind], key=lambda r: -r["score"])
            if not grp:
                continue
            if title:
                lines.append(f"\n<b>{title}</b>")
            for r in grp:
                lines.append(f"{r['score']:+5.1f}  {E(r['name'])} ({r['ticker']}) · {r['label']}")
        if not v.get("has_history"):
            lines.append("\n<i>Sector P/E history not built yet: sectors use price checks only. Open Rotation → Valuation → Build history.</i>")
        return "\n".join(lines)

    def c_sector(self, args):
        from . import sector_alerts as sa
        v = self.api.get_valuation()
        r = self.api.get_rotation("Sectors")
        if not v.get("ok") and not r.get("ok"):
            return f"⚠️ {E(v.get('error') or r.get('error') or 'No data')}"
        vrows = {x["ticker"]: x for x in v.get("rows", [])} if v.get("ok") else {}
        qrows = {x["ticker"]: x for x in r.get("rows", [])} if r.get("ok") else {}
        icons = {"Leading": "🟢", "Improving": "🔵", "Weakening": "🟡", "Lagging": "🔴"}
        pc = lambda x: "–" if x is None else f"{x:+.1f}%"
        if args:
            t = sa.resolve(" ".join(args))
            vr, qr = vrows.get(t), qrows.get(t)
            if not vr and not qr:
                match = [x for x in vrows.values() if x["name"].lower().startswith(" ".join(args).lower())]
                if match:
                    vr = match[0]
                    t = vr["ticker"]
                    qr = qrows.get(t)
            if not vr and not qr:
                return "Unknown sector. Try /sector energy, /sector XLK, /sector gold"
            name = (vr or qr)["name"]
            lines = [f"<b>{E(name)} ({t})</b>"]
            if vr:
                lines.append(f"Valuation: <b>{vr['score']:+.1f}</b> ({vr['label']})" if vr.get("score") is not None else "Valuation: not enough history")
                names = {"pe": "P/E", "ps": "P/S", "fcfy": "FCF yield", "rel": "vs SPY", "stretch": "vs 200-day", "range": "10y range"}
                for k, p in (vr.get("parts") or {}).items():
                    if p and p.get("pct") is not None:
                        now = p.get("now")
                        lines.append(f"  {names.get(k, k)}: {now if now is None else round(now, 2)} · {p['pct']:.0f}th pct of its history")
            if qr:
                lines.append(f"Rotation: {icons.get(qr.get('quadrant'), '')} {qr.get('quadrant') or '–'} · vs SPY 1W {pc(qr['rel'].get('1W'))}, 1M {pc(qr['rel'].get('1M'))}, 3M {pc(qr['rel'].get('3M'))}")
            return "\n".join(lines)
        lines = ["<b>Sectors</b> · valuation (−10…+10) · rotation · 1M vs SPY"]
        secs = [x for x in vrows.values() if x["kind"] == "sector"]
        secs.sort(key=lambda x: -(x["score"] if x["score"] is not None else -99))
        for x in secs:
            q = qrows.get(x["ticker"], {})
            sc = f"{x['score']:+5.1f}" if x["score"] is not None else "  –  "
            lines.append(f"{sc} {E(x['name'])} ({x['ticker']}) · {icons.get(q.get('quadrant'), '')}{q.get('quadrant') or ''} · {pc((q.get('rel') or {}).get('1M'))}")
        return "\n".join(lines)

    def c_gammascan(self, args):
        from . import gamma_scan as gs
        wl = store.watchlist()
        if not wl:
            return "Your watchlist is empty. /watch add NVDA"
        self.progress(f"🧲 Scanning gamma for {len(wl)} tickers… (about {max(1, len(wl) // 6)} min)")
        res = self.api.run_gamma_scan(wl)
        if not res.get("ok"):
            return f"⚠️ {E(res.get('error', 'Gamma scan failed'))}"
        return gs.message(res, detail=not (args and args[0].lower() in ("short", "s", "brief")))

    def c_valert(self, args):
        from . import sector_alerts as sa
        if not args:
            return "e.g. /valert XLE above 6 · /valert gold below -5 · /valert XLK quadrant leading · /valert XLE turns"
        if args[0].lower() in ("delete", "del", "remove") and len(args) > 1 and args[1].isdigit():
            a = sa.remove(int(args[1]))
            return f"🗑 Deleted: {E(sa.describe(a))}"
        if len(args) < 2:
            return "Add a condition: above N, below N, quadrant NAME or turns"
        target, kind = args[0], args[1].lower()
        if kind in ("enters", "into"):
            kind = "quadrant"
        value = args[2] if len(args) > 2 else None
        if kind in ("above", "below", "quadrant") and value is None:
            return "Add a value, e.g. /valert XLE above 6"
        a = sa.add(target, kind, value)
        return f"🔔 Sector alert set: {E(sa.describe(a))}\nChecked after each close. /valerts to list."

    def c_valerts(self, args):
        from . import sector_alerts as sa
        lst = sa.load()
        if not lst:
            return "No sector alerts. e.g. /valert XLE above 6"
        return "<b>Sector alerts</b>\n" + "\n".join(f"{i}. {E(sa.describe(a))}" for i, a in enumerate(lst, 1)) + "\n/valert delete N to remove"

    def c_status(self, args):
        e = self.api._engine
        ok = [p.name for p in e.providers if p.ready()[0] and getattr(p, "key_fields", None)]
        last = store.load("last_scan.json", None)
        lines = ["<b>Goyim Screener is running</b>",
                 f"Market: {'open' if alerts_mod.market_open() else 'closed'}",
                 f"Data sources connected: {E(', '.join(ok)) or 'none'}",
                 f"Active alerts: {sum(1 for a in self._alert_list() if a.get('enabled', True))}"]
        if last:
            lines.append(f"Last scan: {E(str(last.get('run_at', ''))[:16].replace('T', ' '))}")
        if e.status.get("running"):
            lines.append(f"Scanning now: {e.status.get('done', 0)}/{e.status.get('total', 0)}")
        return "\n".join(lines)
