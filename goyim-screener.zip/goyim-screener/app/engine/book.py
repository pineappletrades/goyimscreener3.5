"""Top-of-book sampler: records bid/ask sizes during market hours for stocks sitting near their EMAs.

Public's API only shows the best bid and ask right now (Level 1). There's no history and no Level 2,
so the app keeps its own record: once a minute while the market is open, one batch quote request for
every stock that's close to its 150/200 EMA (yesterday's "approaching" list, the screener's stocks near
a line, and your watchlist). The daily scan then reads today's samples to judge whether bids were
building at the line. Samples are kept for 10 days.
"""
import json
import threading
import time
from datetime import date, datetime, timedelta

from . import paths

KEEP_DAYS = 10


def _dir():
    d = paths.DATA_DIR / "book"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _file(day):
    return _dir() / f"{day}.json"


def load_day(day=None):
    day = day or date.today().isoformat()
    try:
        return json.loads(_file(day).read_text(encoding="utf-8"))
    except Exception:
        return {}


def day_metrics(ticker, line_level=None, day=None, near_pct=3.0):
    """Summary of today's samples for one stock -> {"samples", "bid_share", "bid_growth", "bid_held"} or None.
    bid_share  = average bid size / (bid size + ask size)      (> 0.5 = more size waiting to buy than to sell)
    bid_growth = % change in average bid size, last third of the day vs first third
    bid_held   = when price was near the line, the bid stayed at or above the line (None if never near)"""
    rows = (load_day(day) or {}).get(ticker) or []
    rows = [r for r in rows if r.get("bs") is not None and r.get("as") is not None and (r["bs"] + r["as"]) > 0]
    if not rows:
        return {"samples": 0}
    share = sum(r["bs"] / (r["bs"] + r["as"]) for r in rows) / len(rows)
    third = max(1, len(rows) // 3)
    first = sum(r["bs"] for r in rows[:third]) / third
    last = sum(r["bs"] for r in rows[-third:]) / third
    growth = (last / first - 1) * 100 if len(rows) >= 3 and first > 0 else None
    held = None
    if line_level:
        near = [r for r in rows if r.get("b") and abs(r["p"] / line_level - 1) * 100 <= near_pct]
        if near:
            held = all(r["b"] >= line_level * 0.995 for r in near)
    return {"samples": len(rows), "bid_share": round(share, 3), "bid_growth": None if growth is None else round(growth, 1),
            "bid_held": held, "first": rows[0]["t"], "last": rows[-1]["t"]}


class BookSampler:
    """Background thread. `targets()` returns the tickers to sample; `is_open()` says if the market is open."""

    def __init__(self, engine, targets, is_open, interval=60, log=print, enabled=lambda: True, max_tickers=200):
        self.engine, self.targets, self.is_open = engine, targets, is_open
        self.interval, self.log, self.enabled, self.max_tickers = interval, log, enabled, max_tickers
        self.last_run, self.last_count, self.last_error = None, 0, None
        self._stop = threading.Event()
        self._lock = threading.Lock()

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()
        return self

    def stop(self):
        self._stop.set()

    def _loop(self):
        self._prune()
        while not self._stop.is_set():
            try:
                if self.enabled() and self.is_open():
                    self.sample_once()
            except Exception as e:
                self.last_error = str(e)
                self.log(f"Bid/ask sampler: {e}")
            self._stop.wait(self.interval)

    def sample_once(self, now=None):
        tickers = list(dict.fromkeys(t.upper() for t in (self.targets() or [])))[: self.max_tickers]
        if not tickers:
            return 0
        quotes, _ = self.engine.call_first("quotes", tickers)
        now = now or datetime.now()
        day = now.date().isoformat()
        stamp = now.strftime("%H:%M")
        with self._lock:
            data = load_day(day)
            n = 0
            for t, q in quotes.items():
                if q.get("bid_size") is None and q.get("ask_size") is None:
                    continue
                data.setdefault(t, []).append({"t": stamp, "p": q.get("last"), "b": q.get("bid"), "a": q.get("ask"),
                                               "bs": q.get("bid_size"), "as": q.get("ask_size"), "v": q.get("volume")})
                n += 1
            tmp = _file(day).with_suffix(".tmp")
            tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
            tmp.replace(_file(day))
        self.last_run, self.last_count = now.isoformat(timespec="seconds"), n
        return n

    def _prune(self):
        cut = (date.today() - timedelta(days=KEEP_DAYS)).isoformat()
        for f in _dir().glob("*.json"):
            if f.stem < cut:
                try:
                    f.unlink()
                except Exception:
                    pass
