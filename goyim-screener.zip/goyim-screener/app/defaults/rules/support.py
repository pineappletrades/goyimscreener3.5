"""Support checks: is anyone defending the EMA the stock just touched? Each one can be switched on/off.

History checks use daily price + volume (and are backtested on the Backtest and Strategy Test pages).
Live checks use today's option chain and the bid/ask sizes the app sampled during the day.
"""
from engine.plugin_api import Param, Rule

MISSING = ["Let it through", "Block it"]


def _line(ctx):
    """The average the stock is sitting on: whichever of fast/slow is closest to today's low."""
    prof = ctx.profile
    kind = prof.get("ma_type", "EMA")
    bars = ctx.get("bars")
    fast, slow = ctx.get("ma_fast_series"), ctx.get("ma_slow_series")
    low = float(bars["low"].iloc[-1])
    use_slow = abs(low / float(slow.iloc[-1]) - 1) < abs(low / float(fast.iloc[-1]) - 1)
    length = int(prof.get("slow") if use_slow else prof.get("fast"))
    return kind, length


def full_check(ctx, gamma=False):
    """support.check_today for this stock, cached on the context (one computation shared by every support rule)."""
    from engine import book, support
    key = "support_check_g" if gamma else "support_check"
    hit = ctx.peek(key)
    if hit is not None:
        return hit
    kind, length = _line(ctx)
    bars = ctx.get("bars")
    line_now = float((bars["close"].rolling(length).mean() if kind == "SMA" else bars["close"].ewm(span=length, adjust=False).mean()).iloc[-1])
    g = None
    if gamma:
        loader = getattr(ctx.engine, "gamma_loader", None)
        if loader is not None:
            try:
                g = loader(ctx.ticker, [length])
            except Exception as e:
                g = {"ok": False, "error": str(e)}
    chk = support.check_today(bars, length, kind, gamma=g, book_metrics=book.day_metrics(ctx.ticker, line_now))
    ctx.set(key, chk)
    ctx.set("support_check", chk) if gamma else None
    return chk


class _SupportRule(Rule):
    group = "Support"
    needs = ["bars", "ma_fast_series", "ma_slow_series"]
    default_enabled = False
    signal = ""
    live = False

    def __init__(self):
        self.params = [Param("missing", "If it can't be checked", "Let it through", kind="choice", choices=MISSING)]

    def check(self, ctx, p):
        chk = full_check(ctx, gamma=self.signal in ("gamma_support", "bullish_flow"))
        x = chk["signals"].get(self.signal) or {"ok": None, "detail": "not checked"}
        if x["ok"] is None:
            return p.get("missing", MISSING[0]) == MISSING[0], f"not checked: {x['detail']}"
        return x["ok"], f"{chk['line']}: {x['detail']}"


class LightPullback(_SupportRule):
    id, signal = "sup_light_pullback", "light_pullback"
    name = "Support: pullback on light volume"
    description = "Volume over the 5 days into the touch was below its 50-day average: a calm pullback, not a rush for the exit."


class StrongClose(_SupportRule):
    id, signal = "sup_strong_close", "strong_close"
    name = "Support: closed strong at the line"
    description = "The touch day closed in the top half of its range: buyers stepped in at the line before the close."


class Absorption(_SupportRule):
    id, signal = "sup_absorption", "absorption"
    name = "Support: heavy volume, but it held"
    description = "Touch-day volume at least 1.3× average and the close still in the top half: big buyers absorbed the selling."


class Accumulation(_SupportRule):
    id, signal = "sup_accumulation", "accumulation"
    name = "Support: accumulation into the pullback"
    description = "The accumulation/distribution line rose over the last 20 days: more volume on up-closes than down-closes."


class Respected(_SupportRule):
    id, signal = "sup_respected", "respected"
    name = "Support: this line held before"
    description = "The same line held on at least 60% of its earlier tests in the last ~5 years (2 or more tests)."


class GammaSupport(_SupportRule):
    id, signal, live = "sup_gamma", "gamma_support", True
    name = "Support (live): gamma at the line"
    description = "A put wall or big positive gamma within 1.5% of the line, with price above the gamma flip. Needs Public option chains."


class BullishFlow(_SupportRule):
    id, signal, live = "sup_flow", "bullish_flow", True
    name = "Support (live): bullish option flow"
    description = "Today's estimated option premium leans bullish (calls bought, puts sold). Needs Public option chains."


class BidSupport(_SupportRule):
    id, signal, live = "sup_bids", "bid_support", True
    name = "Support (live): bids building near the line"
    description = ("From the bid/ask sizes the app samples every minute while the market is open: bids outweighed asks, "
                   "kept growing, and held at the line. The app must be open during the day.")
